//LAB 3 - ARRAYS & LOOPS - PART 1


//ARRAY OF FRUITS
var fruits = ["apple", "banana", "cherry", "grape", "orange"];


//OUTPUT ONE FRUIT FROM THE ARRAY IN POPUP BOX
alert(fruits[2]);
console.log(fruits);