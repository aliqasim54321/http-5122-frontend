//LAB 10 - 1 FAQ PAGE

//Listen for window load the jQuery way
jQuery(window).on('load', function() {
	
		$('p').hide();

		$('#h21').on('click',function(){
			$('p').show(3000);
		})

		 		
		$('p').hover(
			function(){$('p').css({'background':'#FFE5C3','color':'#524737'})},
			function(){$('p').css({'background':'#524737','color':'#FFE5C3'});

			
					
				
			
       

});
});

	




	//Inside of here is your jQuery/JavaScript


	//ADD CLICK EVENT TO <h2>
	
	
	
	
	
	
	//CHANGE <p> BACKGROUND ON HOVER






