//######## LAB 2-3 EMAIL SIGNUP ########
//alert("hey 2.3");//COMMENT OUT ONCE CONNECTED TO YOUR HTML PAGE
//==== VARIABLES =========


var say = confirm(" Would you like to join our mailing list");
if(say === true){
    var userinput = prompt ("Please enter your email", " me@example.com ")
//==== LOGIC =============
if (userinput !== null ||userinput !== ""|| userinput !== "me@example.com "){
    alert("Thank you, we will not bother you again");}

else 
  alert("Thank you, our next newsletter will be sent to"+" "+ userinput ) 
    }



 e  